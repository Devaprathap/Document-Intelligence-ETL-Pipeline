# src/extractor.py
"""
Deterministic PDF extractor:
- extracts text with pdfplumber
- optional OCR fallback via pytesseract for scanned PDFs
- regex-based extraction of citations and term-definition pairs
- writes raw text file for debugging
"""

import os
import re
import json
import logging
from typing import List, Dict, Optional

try:
    import pdfplumber
except Exception as e:
    raise RuntimeError("pdfplumber is required. pip install pdfplumber") from e

# Optional OCR imports (only if needed)
try:
    from PIL import Image
    import pytesseract
    OCR_AVAILABLE = True
except Exception:
    OCR_AVAILABLE = False

logging.basicConfig(level=logging.INFO, filename="logs/extractor.log",
                    format="%(asctime)s %(levelname)s %(message)s")


class PDFExtractor:
    def __init__(self, input_dir: str = "data/input_pdfs", raw_out_dir: str = "data/output/raw_texts"):
        self.input_dir = input_dir
        self.raw_out_dir = raw_out_dir
        os.makedirs(self.raw_out_dir, exist_ok=True)

        # Regex patterns - tuned for assignment docs (can be improved iteratively)
        # Citation pattern: matches lines like "Federal Decree-Law No. (7) of 2017 ..." or "Cabinet Resolution No. (55) of 2025 ..."
        self.citation_regex = re.compile(
            r"(?:Federal(?: Decree(?:-Law| by Law)?)|Federal Decree-Law|Cabinet(?: Resolution)?|Cabinet Resolution|Cabinet Res)\b"
            r"[^\n]{0,160}No\.\s*\(?\d+\)?\s*of\s*(?:19|20)\d{2}[^\n\.;]*",
            flags=re.IGNORECASE
        )

        # Term-definition pairs: a term on left then ":" or "-" and definition text
        # We capture term as leading capitalized word(s) and a definition that may span lines until double newline or next term.
        self.term_def_regex = re.compile(
            r"(?P<term>[A-Z][A-Za-z0-9 &\-\(\)\'\"]{1,120}?)\s*[:\-]\s*(?P<defn>(?:[A-Z0-9a-z][^\n]*?(?:\n|$)){1,6})",
            flags=re.MULTILINE
        )

    def extract_text(self, pdf_path: str) -> str:
        """Extract text using pdfplumber. Returns joined page text."""
        texts = []
        try:
            with pdfplumber.open(pdf_path) as pdf:
                for i, page in enumerate(pdf.pages):
                    page_text = page.extract_text() or ""
                    # normalize whitespace
                    page_text = page_text.replace("\r", "\n")
                    texts.append(f"\n\n--- PAGE {i+1} ---\n\n" + page_text)
        except Exception as e:
            logging.exception(f"pdfplumber extraction failed for {pdf_path}: {e}")
            # try OCR fallback if available
            if OCR_AVAILABLE:
                logging.info("Attempting OCR fallback for %s", pdf_path)
                ocr_text = self.ocr_extract(pdf_path)
                return ocr_text
            raise
        return "\n".join(texts)

    def ocr_extract(self, pdf_path: str) -> str:
        """Fallback OCR extraction for scanned PDFs (requires pytesseract + PIL + tesseract binary)"""
        if not OCR_AVAILABLE:
            raise RuntimeError("OCR packages not installed (pytesseract/PIL)")
        try:
            import pdf2image  # note: user may need to pip install pdf2image
        except Exception:
            raise RuntimeError("pdf2image required for OCR fallback: pip install pdf2image")
        try:
            pages = pdf2image.convert_from_path(pdf_path)
            texts = []
            for i, img in enumerate(pages):
                txt = pytesseract.image_to_string(img)
                texts.append(f"\n\n--- PAGE {i+1} (OCR) ---\n\n{txt}")
            return "\n".join(texts)
        except Exception as e:
            logging.exception("OCR extraction failed for %s: %s", pdf_path, e)
            return ""

    def find_citations(self, text: str) -> List[str]:
        """Return a deduplicated list of citations."""
        matches = self.citation_regex.findall(text)
        # findall returns matched strings; ensure uniqueness while preserving order
        seen = set()
        out = []
        for m in matches:
            cleaned = " ".join(m.split())
            if cleaned.lower() not in seen:
                seen.add(cleaned.lower())
                out.append(cleaned)
        return out

    def find_term_defs(self, text: str) -> List[Dict[str, str]]:
        """Return list of {'term':..., 'definition':...} using regex captures."""
        out = []
        for m in self.term_def_regex.finditer(text):
            term = m.group("term").strip()
            definition = m.group("defn").strip().replace("\n", " ").strip()
            # simple heuristic: ignore short single-word definitions (reduce noise)
            if len(definition) < 3:
                continue
            out.append({"term": term, "definition": definition})
        # dedupe by term (keep first)
        seen = set()
        deduped = []
        for td in out:
            tkey = td["term"].lower()
            if tkey not in seen:
                seen.add(tkey)
                deduped.append(td)
        return deduped

    def save_raw_text(self, filename: str, text: str):
        """Write raw extracted text to file for debugging."""
        base = os.path.basename(filename)
        name = os.path.splitext(base)[0]
        out_path = os.path.join(self.raw_out_dir, f"{name}_raw.txt")
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(text)
        logging.info("Saved raw text to %s", out_path)
        return out_path

    def process_file(self, filename: str) -> Dict:
        """Process single PDF file and return extraction dict."""
        path = os.path.join(self.input_dir, filename)
        logging.info("Processing %s", path)
        text = self.extract_text(path)
        self.save_raw_text(filename, text)

        citations = self.find_citations(text)
        term_defs = self.find_term_defs(text)

        result = {
            "source_file": filename,
            "citations": citations,
            "term_defs": term_defs,
            "pages_estimated": text.count("--- PAGE")
        }
        logging.info("File %s: %d citations, %d term_defs", filename, len(citations), len(term_defs))
        return result

    def process_all(self) -> List[Dict]:
        """Process all PDFs present in input_dir."""
        outputs = []
        files = [f for f in os.listdir(self.input_dir) if f.lower().endswith(".pdf")]
        logging.info("Found %d PDF files in %s", len(files), self.input_dir)
        for f in sorted(files):
            try:
                out = self.process_file(f)
                outputs.append(out)
            except Exception as e:
                logging.exception("Failed to process %s: %s", f, e)
        return outputs


if __name__ == "__main__":
    # quick local test run on data/input_pdfs
    extractor = PDFExtractor()
    results = extractor.process_all()
    # write a small json summary for inspection
    with open("data/output/extractor_summary.json", "w", encoding="utf-8") as jf:
        json.dump(results, jf, ensure_ascii=False, indent=2)
    print("Extraction complete. Summary written to data/output/extractor_summary.json")