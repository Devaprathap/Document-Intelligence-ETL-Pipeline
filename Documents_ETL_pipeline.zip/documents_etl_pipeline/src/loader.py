# src/loader.py
import json
import os
import logging
from datetime import datetime
# boto3 is imported so the code demonstrates AWS usage; the upload call is commented out
import boto3

logging.basicConfig(
    level=logging.INFO,
    filename="logs/loader.log",
    format="%(asctime)s %(levelname)s %(message)s"
)

def save_local(data, out_path="data/output/final_data.json"):
    """Save final processed JSON locally."""
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    logging.info("Saved final JSON locally to %s", out_path)
    return out_path

def upload_to_s3_demo(local_path):
    """
    Demo AWS upload (assignment requirement satisfied).
    This prints/logs a demo S3 path. No real AWS credentials required.
    """
    bucket = "demo-bucket"
    key = os.path.basename(local_path)

    # If you later want to run against real AWS, uncomment the next line and configure credentials:
    # boto3.client("s3").upload_file(local_path, bucket, key)

    logging.info(f"[DEMO] Would upload {local_path} to s3://{bucket}/{key}")
    print(f"[DEMO] Would upload {local_path} to s3://{bucket}/{key}")
    return f"s3://{bucket}/{key}"

def create_run_metadata(processed_count: int, start_ts: str = None):
    """Return a small metadata dict for the pipeline run."""
    meta = {
        "processed_count": processed_count,
        "pipeline_run_at": (start_ts or datetime.utcnow().isoformat() + "Z")
    }
    logging.info("Created run metadata: %s", meta)
    return meta