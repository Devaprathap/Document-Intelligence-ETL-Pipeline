# src/transformer.py
"""
Transformer: reads extractor_summary.json, canonicalizes citations, normalizes terms/definitions,
deduplicates, and writes final_data.json ready for loading.
"""

import os
import re
import json
import logging
from typing import List, Dict

logging.basicConfig(level=logging.INFO, filename="logs/transformer.log",
                    format="%(asctime)s %(levelname)s %(message)s")


def canonicalize_title(title: str) -> str:
    """
    Turn legal titles into canonical ids.
    Examples:
      "Federal Decree by Law No. (47) of 2022 Concerning Corporate and Business Tax"
      -> "fed_decree_law_47_2022"
    Keeps numeric id + year; strips punctuation and non-essential words.
    """
    if not title or not isinstance(title, str):
        return "unknown_document"

    t = title.strip()

    # common normalizations
    t = t.replace("–", "-").replace("—", "-")
    t = re.sub(r"\s+", " ", t)  # collapse whitespace

    # match Federal Decree / Federal Decree-Law / Cabinet Resolution / Cabinet Res / Decree Law etc.
    # capture number inside parentheses or after No.
    match_fd = re.search(r"(?:federal\s+decree(?:-law| by law)?|federal\s+decree-law)\s*[^0-9\n\r]{0,10}\(?\s*(\d{1,4})\s*\)?\s*of\s*(\d{4})",
                         t, flags=re.IGNORECASE)
    if match_fd:
        num, year = match_fd.group(1), match_fd.group(2)
        return f"fed_decree_law_{num}_{year}"

    match_cab = re.search(r"(?:cabinet\s+resolution|cab_res|cabinet\Wres)\s*[^0-9\n\r]{0,10}\(?\s*(\d{1,4})\s*\)?\s*of\s*(\d{4})",
                          t, flags=re.IGNORECASE)
    if match_cab:
        num, year = match_cab.group(1), match_cab.group(2)
        return f"cab_res_{num}_{year}"

    # generic Decree/Law (fallback)
    match_gen = re.search(r"(?:decree(?:-law)?|law|resolution)[^\d]{0,20}\(?\s*(\d{1,4})\s*\)?\s*of\s*(\d{4})",
                          t, flags=re.IGNORECASE)
    if match_gen:
        num, year = match_gen.group(1), match_gen.group(2)
        # sanitize prefix
        prefix = re.sub(r"[^\w]+", "_", t.split()[0].lower())
        return f"{prefix}_{num}_{year}"

    # fallback: remove non-alphanum and shorten
    simple = re.sub(r"[^\w]+", "_", t.lower()).strip("_")
    if len(simple) > 60:
        simple = simple[:60].rstrip("_")
    return simple or "unknown_document"


def normalize_citation_string(s: str) -> str:
    """Clean whitespace, unify 'No.' formatting, remove trailing punctuation."""
    if not s or not isinstance(s, str):
        return s
    s = s.strip()
    s = re.sub(r"\s+", " ", s)
    s = s.replace("No .", "No.")
    s = re.sub(r"\s*\.\s*$", "", s)  # strip trailing dot
    return s


def normalize_term_def(td: Dict[str, str]) -> Dict[str, str]:
    """Normalize term/definition pair: strip, fix quotes, remove repeated spaces."""
    term = td.get("term", "") or ""
    definition = td.get("definition", "") or ""

    term = term.strip()
    term = re.sub(r"\s+", " ", term)
    # unify curly quotes
    term = term.replace("“", '"').replace("”", '"').replace("’", "'")

    definition = definition.strip()
    definition = re.sub(r"\s+", " ", definition)
    definition = definition.replace("“", '"').replace("”", '"').replace("’", "'")
    # remove leading ':' or '-' if present
    definition = re.sub(r"^[\:\-\s]+", "", definition)
    return {"term": term, "definition": definition}


def transform_extractor_summary(summary_path: str = "data/output/extractor_summary.json",
                                out_path: str = "data/output/final_data.json") -> Dict:
    """
    Read extractor summary, canonicalize and normalize, dedupe citations and terms,
    produce final JSON schema.
    """
    if not os.path.exists(summary_path):
        raise FileNotFoundError(f"{summary_path} not found. Run extractor first.")

    with open(summary_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # global maps
    canonical_map = {}   # canonical_id -> canonical title (first seen)
    citation_map = {}    # normalized citation string -> canonical_id
    documents_out = []

    for doc in data:
        src = doc.get("source_file")
        citations = doc.get("citations", [])
        term_defs = doc.get("term_defs", [])

        # normalize citation strings
        norm_cits = [normalize_citation_string(c) for c in citations if c and isinstance(c, str)]

        # choose primary canonical id: try first citation else fallback to filename
        primary_source = norm_cits[0] if norm_cits else src
        cand_id = canonicalize_title(primary_source)

        # if this canonical id already exists but with different text, keep first occurrence's label
        if cand_id in canonical_map:
            canonical_id = cand_id
        else:
            canonical_id = cand_id
            canonical_map[canonical_id] = primary_source

        # map all citations in this doc to the canonical_id
        for c in norm_cits:
            citation_map[c.lower()] = canonical_id

        # normalize term/definitions
        normalized_terms = [normalize_term_def(td) for td in term_defs]

        # dedupe terms by lower(term)
        seen_terms = set()
        dedup_terms = []
        for td in normalized_terms:
            key = td["term"].lower()
            if key and key not in seen_terms:
                seen_terms.add(key)
                dedup_terms.append(td)

        doc_entry = {
            "document_id": canonical_id,
            "source_file": src,
            "citations": norm_cits,
            "terms": dedup_terms,
            "pages_estimated": doc.get("pages_estimated", 0)
        }
        documents_out.append(doc_entry)
        logging.info("Transformed %s -> %s (%d terms, %d citations)",
                     src, canonical_id, len(dedup_terms), len(norm_cits))

    # Build canonical documents index: aggregate all docs with same canonical id
    agg = {}
    for d in documents_out:
        cid = d["document_id"]
        if cid not in agg:
            agg[cid] = {
                "document_id": cid,
                "canonical_title": canonical_map.get(cid, ""),
                "source_files": [],
                "citations": set(),
                "terms": []
            }
        agg[cid]["source_files"].append(d["source_file"])
        for c in d["citations"]:
            agg[cid]["citations"].add(c)
        # append terms (do not dedupe across files here; optional later)
        agg[cid]["terms"].extend(d["terms"])

    # finalize structure and convert sets to lists, dedupe terms across aggregated doc
    final_docs = []
    for cid, v in agg.items():
        # dedupe terms by term lower
        seen = set(); terms = []
        for td in v["terms"]:
            k = td["term"].lower()
            if k and k not in seen:
                seen.add(k); terms.append(td)
        final_docs.append({
            "document_id": cid,
            "canonical_title": v["canonical_title"],
            "source_files": v["source_files"],
            "citations": sorted(list(v["citations"])),
            "terms": terms
        })

    final_output = {
        "documents": final_docs,
        "meta": {
            "pipeline_stage": "transformed",
            "source_summary": os.path.basename(summary_path)
        }
    }

    # write output
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(final_output, f, ensure_ascii=False, indent=2)

    logging.info("Wrote transformed final_data to %s", out_path)
    return final_output


if __name__ == "__main__":
    out = transform_extractor_summary()
    print(f"Transformed {len(out['documents'])} documents. Output: data/output/final_data.json")