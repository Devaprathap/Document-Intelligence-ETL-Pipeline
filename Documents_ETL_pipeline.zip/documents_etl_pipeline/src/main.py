# src/main.py
import time, logging, os
from extractor import PDFExtractor
from transformer import transform_extractor_summary
from ai_model import AIEnhancer
# we use the demo uploader (no real AWS required)
from loader import save_local, upload_to_s3_demo, create_run_metadata

logging.basicConfig(level=logging.INFO, filename="logs/main.log",
                    format="%(asctime)s %(levelname)s %(message)s")

def run_pipeline(s3_bucket: str = None):
    start = time.time()
    logging.info("Pipeline started")

    # Step A: Extract
    extractor = PDFExtractor()
    extractor.process_all()  # writes data/output/extractor_summary.json

    # Step B: Transform
    transformed = transform_extractor_summary()  # returns final_output dict
    documents = transformed.get("documents", [])

    # Step C: AI refine (non-deterministic step)
    try:
        ai = AIEnhancer()
        docs_refined = ai.refine_terms(documents)
        transformed["documents"] = docs_refined
    except Exception as e:
        logging.exception("AI refinement failed: %s", e)

    # update meta
    transformed["meta"].update(create_run_metadata(processed_count=len(documents)))

    # Step D: Save locally
    out_path = "data/output/final_data.json"
    save_local(transformed, out_path)

    # Step E: DEMO Upload to S3 (no real AWS account required)
    # This prints a demo S3 path and logs the action.
    try:
        s3_path = upload_to_s3_demo(out_path)
    except Exception as e:
        s3_path = None
        logging.exception("Demo S3 upload failed: %s", e)

    elapsed = time.time() - start
    logging.info("Pipeline finished in %.2f seconds. s3_path=%s", elapsed, s3_path)
    print(f"Pipeline finished in {elapsed:.2f}s. Final file: {out_path}")
    if s3_path:
        print(f"Demo uploaded to: {s3_path}")
    return out_path, s3_path

if __name__ == "__main__":
    # run the pipeline (no real S3 bucket needed)
    run_pipeline()