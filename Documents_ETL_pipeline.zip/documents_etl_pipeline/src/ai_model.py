# src/ai_model.py  (simple, local refinement)
import spacy, logging
nlp = spacy.load("en_core_web_sm")

logging.basicConfig(level=logging.INFO, filename="logs/ai_model.log",
                    format="%(asctime)s %(levelname)s %(message)s")

class AIEnhancer:
    def refine_terms(self, docs: list):
        """
        docs: list of dict {document_id, terms: [{term,definition}, ...], ...}
        returns docs with cleaned / slightly improved definitions
        """
        for d in docs:
            new_terms = []
            for td in d.get("terms", []):
                def_text = td.get("definition", "")
                # simple NLP cleanup: remove extraneous whitespace, fix sentence segmentation
                doc = nlp(def_text)
                sentences = [sent.text.strip() for sent in doc.sents]
                cleaned = " ".join(sentences).strip()
                # optional: if definition is too short, append context hint (NOT invasive)
                td["definition"] = cleaned if cleaned else def_text
                new_terms.append(td)
            d["terms"] = new_terms
        logging.info("AIEnhancer refined %d documents", len(docs))
        return docs