# src/utils.py

import re

def clean_text(text: str) -> str:
    """Basic cleanup for extracted text."""
    if not text:
        return ""
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def normalize_whitespace(text: str) -> str:
    """Normalize whitespace across the pipeline."""
    return " ".join(text.split())